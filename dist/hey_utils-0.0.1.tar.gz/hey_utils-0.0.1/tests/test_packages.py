
import pytest
import hey_utils

@pytest.mark.skip(reason="no way of currently testing this")
def test_skip():
    assert 1 != 1
    
    
def test_gRPC():
    response = hey_utils.get_test()
    assert response is not None
    assert response == "ok"
    
    
    
    
    